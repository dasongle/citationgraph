#!/bin/bash
make

dataset=cora
data_root=$dataset

result_root=$HOME/scratch/results/admm_nofeat/$dataset

batch_size=128
n_hidden=16
n_embed=16
learning_rate=0.001
max_iter=10000
max_bp_iter=1
cur_iter=0
w_scale=0.01
save_dir=$result_root/embed-$n_embed

if [ ! -e $save_dir ];
then
    mkdir -p $save_dir
fi

./build/main \
    -feat $data_root/features.txt \
    -train_idx $data_root/train_idx.txt \
    -test_idx $data_root/test_idx.txt \
    -max_bp_iter $max_bp_iter \
    -data_root $data_root \
    -n_hidden $n_hidden \
    -lr $learning_rate \
    -max_iter $max_iter \
    -svdir $save_dir \
    -embed $n_embed \
    -batch_size $batch_size \
    -m 0.9 \
    -l2 0.0001 \
    -w_scale $w_scale \
    -int_report 10 \
    -int_test 100 \
    -int_save 100 \
    -cur_iter $cur_iter \
    2>&1 | tee $save_dir/log.txt
