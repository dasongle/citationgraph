#include "config.h"
#include "nn/nn_all.h"
#include "tensor/tensor_all.h"
#include <algorithm>
#include "global.h"
#include "func_net.h"
#include "util.h"

FuncNet* fnet;

using namespace gnn;

// void MacroF1(std::vector< std::vector<int> >& test_pred, std::vector< std::vector<int> >& test_label)
// {
//     double f1 = 0.0;
//     for (int t = 0; t < cfg::num_labels; ++t)
//     {
//         double tp = 0.0, fp = 0.0, fn = 0.0;
//         for (size_t i = 0; i < test_pred[t].size(); ++i)
//         {
//             if (test_pred[t][i] == test_label[t][i])
//             {
//                 if (test_label[t][i] == 1)
//                     tp++;
//             } else {
//                 if (test_pred[t][i] == 1)
//                     fp++;
//                 else
//                     fn++;
//             }
//         }
//         double prec = tp / (tp + fp);
//         double rec = tp / (tp + fn);
//         if (prec + rec > 1e-8)
//             f1 += 2 * prec * rec / (prec + rec);
//     }
//     std::cerr << f1 / cfg::num_labels << std::endl;
// }

// void F1(std::vector< int >& test_pred, std::vector< int >& test_label)
// {
//     double f1 = 0.0, tp = 0.0, fp = 0.0, fn = 0.0;
//     for (size_t i = 0; i < test_pred.size(); ++i)
//     {
//         if (test_pred[i] == test_label[i])
//         {
//             if (test_label[i] == 1)
//                 tp++;
//         } else {
//             if (test_pred[i] == 1)
//                 fp++;
//             else
//                 fn++;
//         }
//     }
//     double prec = tp / (tp + fp);
//     double rec = tp / (tp + fn);
//     if (prec + rec > 1e-8)
//         f1 += 2 * prec * rec / (prec + rec);
//     std::cerr << f1 << std::endl;
// }

void TestLoop(std::vector<int>& cur_test_idxes)
{
    fnet->BuildBatchGraph(cur_test_idxes);
    fnet->fg.FeedForward({fnet->loss, fnet->acc}, fnet->inputs, Phase::TEST);
    std::cerr << fnet->loss->value.AsScalar() << " " << fnet->acc->value.AsScalar() << std::endl;
}

void MainLoop()
{
	//MomentumSGDOptimizer<mode, Dtype> learner(&model, cfg::lr, cfg::momentum, cfg::l2_penalty);
	AdamOptimizer<mode, Dtype> learner(&model, cfg::lr, cfg::l2_penalty);
    std::cerr << "main loop" << std::endl;
	int max_iter = (long long)cfg::max_iter;
	int init_iter = cfg::iter;
	if (init_iter > 0)
	{
		std::cerr << fmt::sprintf("loading model for iter=%d", init_iter) << std::endl;
		model.Load(fmt::sprintf("%s/iter_%d.model", cfg::save_dir, init_iter));
	}
	
	for (; cfg::iter <= max_iter; ++cfg::iter)
	{
		if (cfg::iter % cfg::test_interval == 0)
		{	
            TestLoop(test_idxes);
		}
		if (cfg::iter % cfg::save_interval == 0 && cfg::iter != init_iter)
		{			
			printf("saving model for iter=%d\n", cfg::iter);
			model.Save(fmt::sprintf("%s/iter_%d.model", cfg::save_dir, cfg::iter));
		}

        fnet->BuildBatchGraph(train_idxes);
        fnet->fg.FeedForward({fnet->loss}, fnet->inputs, Phase::TRAIN);
        fnet->fg.BackPropagate({fnet->loss});
        learner.Update();

    	if (cfg::iter % cfg::report_interval == 0)
		{	
            std::cerr << "iter: " << cfg::iter;
            std::cerr << "\tloss: " << fnet->loss->value.AsScalar() << std::endl;
		}
	}
}

int main(const int argc, const char** argv)
{
	srand(time(NULL));
	cfg::LoadParams(argc, argv);
	GpuHandle::Init(cfg::dev_id, 1);

    std::cerr << "loading graph" << std::endl;
    LoadGraph(cfg::data_root);

    std::cerr << "loading idxes" << std::endl;
    LoadIdxes(cfg::f_train_idx, train_idxes);
    LoadIdxes(cfg::f_test_idx, test_idxes);

    std::cerr << "loading features" << std::endl;
    LoadFeat(cfg::f_feat);
    std::cerr << "everyting loaded" << std::endl;

    fnet = new FuncNet();
    MainLoop();

    // auto& node_embed = model.nondiff_params["node_embed"]->value;
    // for (int i = 0; i < 10; ++i)
    // {
    //     for (int j = 0; j < 10; ++j)
    //         std::cerr << node_embed.data->ptr[i * node_embed.cols() + j] << " ";
    //     std::cerr << std::endl;
    // }
	GpuHandle::Destroy();
	return 0;	
}
