#include "config.h"

int cfg::iter = 0;
int cfg::n_hidden = 128;
int cfg::num_nodes = 0;
int cfg::num_class = 0;
int cfg::max_bp_iter = 0;
int cfg::dim_feat = 0;
unsigned cfg::n_embed = 128;
unsigned cfg::max_iter = 0;
unsigned cfg::dev_id = 0;
unsigned cfg::batch_size = 32;
unsigned cfg::test_interval = 10000;
unsigned cfg::report_interval = 100;
unsigned cfg::save_interval = 50000;
Dtype cfg::lr = 0.0005;
Dtype cfg::l2_penalty = 0;
Dtype cfg::momentum = 0;
Dtype cfg::w_scale = 0.01;
const char* cfg::save_dir = "./saved";
const char* cfg::data_root = nullptr;
const char* cfg::f_train_idx = nullptr;
const char* cfg::f_test_idx = nullptr;
const char* cfg::f_feat = nullptr;