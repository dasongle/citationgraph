#include "func_net.h"
#include "graph.h"
#include "util/graph_struct.h"
#include <algorithm>
#include "global.h"

FuncNet::FuncNet()
{
    std::cerr << "init net" << std::endl;
    inputs.clear();
    int nnz = 0;
    for (int i = 0; i < cfg::num_nodes; ++i)
        nnz += node_list[i]->adj_list.size();

    n2n.Reshape({(size_t)cfg::num_nodes, (size_t)cfg::num_nodes});
    n2n.ResizeSp(nnz, cfg::num_nodes + 1);
    nnz = 0;
    for (int i = 0; i < cfg::num_nodes; ++i)
    {
        n2n.data->row_ptr[i] = nnz;
        for (auto v : node_list[i]->adj_list)
        {
            n2n.data->col_idx[nnz] = v->idx;
            n2n.data->val[nnz] = 1.0 / node_list[i]->adj_list.size();
            nnz++;
        }
    }
    assert(nnz == n2n.data->nnz);
    n2n.data->row_ptr[cfg::num_nodes] = nnz;
    m_n2n.CopyFrom(n2n);
    inputs["n2n"] = &m_n2n;
    inputs["node_input"] = &m_node_feat;
    
    std::cerr << "building graph" << std::endl;
    BuildNet();
    std::cerr << "fnet built" << std::endl;
}

void FuncNet::BuildNet()
{
    auto init_w = add_diff<DTensorVar>(model, "init_w", {(size_t)cfg::dim_feat, (size_t)cfg::n_embed});
    init_w->value.SetRandN(0, cfg::w_scale);
    fg.AddParam(init_w);
    auto node_input = add_const< SpTensorVar<mode, Dtype> >(fg, "node_input", true);
    auto node_embed = af< MatMul >(fg, {node_input, init_w});

    auto p_node_conv = add_diff<DTensorVar>(model, "p_node_conv", {(size_t)cfg::n_embed, (size_t)cfg::n_embed});
    auto classifier = add_diff<DTensorVar>(model, "classifier", {(size_t)cfg::n_hidden, (size_t)cfg::num_class});
    p_node_conv->value.SetRandN(0, cfg::w_scale);
    classifier->value.SetRandN(0, cfg::w_scale);
    fg.AddParam(p_node_conv);
    fg.AddParam(classifier);

    auto n2n_message = add_const< SpTensorVar<mode, Dtype> >(fg, "n2n", true);
    auto cur_embed = node_embed;
    int lv = 0;
    while (lv < cfg::max_bp_iter)
    {
        auto n2npool = af<MatMul>(fg, {n2n_message, cur_embed});
        auto node_linear = af<MatMul>(fg, {n2npool, p_node_conv});
        auto merged_linear = af<ElewiseAdd>(fg, {node_linear, node_embed});
        cur_embed = af< ReLU >(fg, {merged_linear});
        lv++;
    }
    node_embed = cur_embed;

    auto node_select = add_const< SpTensorVar<mode, Dtype> >(fg, "node_select", true);
    auto v_i = af< MatMul >(fg, {node_select, node_embed});

    auto h1 = v_i;
    auto pred_linear = af< MatMul >(fg, {h1, classifier});

    auto label = add_const< SpTensorVar<mode, Dtype> >(fg, "label", true);
    auto ce = af< CrossEntropy >(fg, {pred_linear, label}, true);
    loss = af< ReduceMean >(fg, {ce});

    auto y = af< ArgMax >(fg, {label});
    auto cmp = af< InTopK<mode, Dtype> >(fg, std::make_pair(pred_linear, y));
    auto real_cmp = af< TypeCast<mode, Dtype> >(fg, {cmp});
    acc = af< ReduceMean >(fg, { real_cmp });
}

void FuncNet::BuildBatchGraph(std::vector<int>& nodes)
{
    int nnz_node = nodes.size();

    batch_label.Reshape({nodes.size(), (size_t)cfg::num_class});
    batch_label.ResizeSp(nodes.size(), nodes.size() + 1);
    mat_select.Reshape({nodes.size(), (size_t)cfg::num_nodes});
    mat_select.ResizeSp(nnz_node, nodes.size() + 1);

    nnz_node = 0;
    for (size_t i = 0; i < nodes.size(); ++i)
    {
        mat_select.data->row_ptr[i] = nnz_node;
        mat_select.data->col_idx[i] = nodes[i];
        mat_select.data->val[i] = 1.0;
        nnz_node++;
        
        batch_label.data->row_ptr[i] = i; 
        batch_label.data->val[i] = 1.0;
        batch_label.data->col_idx[i] = labels[nodes[i]];
    }
    batch_label.data->row_ptr[nodes.size()] = nodes.size();
    m_batch_label.CopyFrom(batch_label);
    assert(nnz_node == mat_select.data->nnz);
    mat_select.data->row_ptr[nodes.size()] = nnz_node;

    m_mat_select.CopyFrom(mat_select);
    m_batch_label.CopyFrom(batch_label);

    inputs["node_select"] = &m_mat_select;
    inputs["label"] = &m_batch_label;
}
