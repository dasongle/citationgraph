#include "graph.h"
#include "config.h"
#include <string>
#include <vector>
#include <queue>
#include "global.h"

Node::Node(int _idx) : idx(_idx)
{
    adj_list.clear();    
}

void Node::AddNeighbor(Node* y)
{
    adj_list.push_back(y);
}

bool Node::SampleNeighbor(Node* j)
{
    double frac = (double)j->adj_list.size() / ((double)adj_list.size() + 20.0);
    frac = 0.1 + 0.5 * frac;
    return (distribution(generator) < frac);
}

std::default_random_engine Node::generator;
std::uniform_real_distribution<double> Node::distribution(0.0, 1.0);

void LoadGraph(const char* data_root)
{
    FILE* f_meta = fopen(fmt::sprintf("%s/meta.txt", data_root).c_str(), "r");
    int num_nodes, num_class, dim_feat;
    fscanf(f_meta, "%d %d %d", &num_nodes, &num_class, &dim_feat); 
    fclose(f_meta);

    FILE* f_adj = fopen(fmt::sprintf("%s/adj_list.txt", data_root).c_str(), "r");
    node_list.resize(num_nodes);
    for (int i = 0; i < num_nodes; ++i)
        node_list[i] = new Node(i);
    
    for (int i = 0; i < num_nodes; ++i)
    {
        int m;
        fscanf(f_adj, "%d", &m);
        for (int j = 0; j < m; ++j)
        {
            int v;
            fscanf(f_adj, "%d", &v);
            assert(v >= 0 && v < num_nodes);
            node_list[i]->AddNeighbor(node_list[v]);
        }
    }
    fclose(f_adj);

    FILE* f_label = fopen(fmt::sprintf("%s/label.txt", data_root).c_str(), "r");
    labels.resize(num_nodes);
    for (int i = 0; i < num_nodes; ++i)
    {
        for (int j = 0; j < num_class; ++j)
        {
            int tmp;
            fscanf(f_label, "%d", &tmp);
            if (tmp)
                labels[i] = j;
        }
    }
    fclose(f_label);
    cfg::num_nodes = num_nodes;
    cfg::num_class = num_class;
    cfg::dim_feat = dim_feat;
}