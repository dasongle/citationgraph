#include "global.h"

std::vector<Node*> node_list;
ParamSet<mode, Dtype> model;
std::vector<int> train_idxes, test_idxes;
std::vector< int > labels;
SpTensor<CPU, Dtype> node_feat;
SpTensor<mode, Dtype> m_node_feat;