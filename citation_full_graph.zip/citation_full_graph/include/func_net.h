#ifndef FUNC_NET_H
#define FUNC_NET_H

#include <map>
#include <string>
#include <vector>
#include "config.h"
#include "tensor/tensor.h"
#include "nn/nn_all.h"

using namespace gnn;

class FuncNet
{
public:
    FuncNet();

    void BuildNet();
    void BuildBatchGraph(std::vector<int>& nodes);

    SpTensor<CPU, Dtype> mat_select, n2n, batch_label;
    SpTensor<mode, Dtype> m_mat_select, m_n2n, m_batch_label;

    std::map< std::string, void* > inputs;
    std::shared_ptr< DTensorVar<mode, Dtype> > loss, acc;
    FactorGraph fg;
};

#endif