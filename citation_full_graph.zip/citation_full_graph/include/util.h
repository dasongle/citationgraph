#ifndef UTIL_H
#define UTIL_H

#include "config.h"
#include "tensor/tensor_all.h"
#include <string>

using namespace gnn;

void Normalize(DTensor<mode, Dtype>& embed_mat);

void Normalize(DTensor<mode, Dtype>& embed_mat, int row_idx);

void LoadIdxes(const char* fname, std::vector<int>& idx_set);

void LoadFeat(const char* fname);

#endif