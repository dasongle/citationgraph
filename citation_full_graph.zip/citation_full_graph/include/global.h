#ifndef GLOBAL_H
#define GLOBAL_H

#include "config.h"
#include "nn/factor_graph.h"
#include "nn/param_set.h"
#include "tensor/tensor_all.h"
#include "graph.h"
#include <map>

using namespace gnn;

extern std::vector<Node*> node_list;
extern ParamSet<mode, Dtype> model;
extern std::vector<int> train_idxes, test_idxes;
extern std::vector< int > labels;
extern SpTensor<CPU, Dtype> node_feat;
extern SpTensor<mode, Dtype> m_node_feat;

#endif